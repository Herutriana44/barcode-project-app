<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-wrap justify-between items-center gap-3">
            <h2 class="font-semibold text-xl text-egg-900 leading-tight">
                <?php echo e(__('Detail Barcode Perusahaan')); ?>

            </h2>
            <div class="flex flex-wrap gap-2 justify-end">
                <button type="button" onclick="window.print()" class="btn-egg-primary">Print</button>
                <a href="<?php echo e(route('company-barcodes.create')); ?>" class="btn-egg-primary">Buat Baru</a>
                <a href="<?php echo e(route('company-barcodes.index')); ?>" class="btn-egg-secondary">Kembali</a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 print:shadow-none">
                <div class="border-2 border-egg-200 p-6 rounded-lg">
                    <div class="flex flex-col sm:flex-row flex-wrap items-start justify-center gap-10 mb-6 print:flex-row print:gap-8">
                        <div class="flex flex-col items-center w-full sm:w-auto">
                            <span class="text-xs font-medium text-egg-700 mb-2 uppercase tracking-wide">Barcode (Code 128)</span>
                            <div class="barcode-container overflow-x-auto max-w-full">
                                <?php echo $barcodeSvg; ?>

                            </div>
                        </div>
                        <div class="flex flex-col items-center w-full sm:w-auto">
                            <span class="text-xs font-medium text-egg-700 mb-2 uppercase tracking-wide">Kode QR</span>
                            <div class="qr-container w-[180px] max-w-full flex justify-center [&_svg]:max-w-full [&_svg]:h-auto">
                                <?php echo $qrCodeSvg; ?>

                            </div>
                        </div>
                    </div>
                    <p class="text-center text-base font-mono mb-6 font-medium text-egg-900"><?php echo e($companyBarcode->barcode_id); ?></p>

                    <h3 class="font-semibold text-lg mb-4"><?php echo e($companyBarcode->company->name); ?></h3>

                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="border-b">
                                <th class="text-left py-2">Nama Barang</th>
                                <th class="text-left py-2">Qty</th>
                                <th class="text-left py-2">Posisi Rak</th>
                                <th class="text-left py-2">Tingkat</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $companyBarcode->company->companyItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b">
                                    <td class="py-2"><?php echo e($ci->item->part_name ?? $ci->item->part_number ?? 'Item #'.$ci->item->id); ?></td>
                                    <td class="py-2"><?php echo e($ci->qty); ?></td>
                                    <td class="py-2"><?php echo e($ci->posisi_rak ?? '-'); ?></td>
                                    <td class="py-2"><?php echo e($ci->tingkat ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/company-barcodes/show.blade.php ENDPATH**/ ?>