<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'alt' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'alt' => null,
]); ?>
<?php foreach (array_filter(([
    'alt' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<img
    src="<?php echo e(asset('icon.png')); ?>"
    alt="<?php echo e($alt ?? config('app.name', 'Logo')); ?>"
    <?php echo e($attributes->merge(['class' => 'shrink-0 object-contain'])); ?>

/>
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/components/application-logo.blade.php ENDPATH**/ ?>