<link rel="icon" type="image/png" href="<?php echo e(asset('icon.png')); ?>">
<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('icon.png')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(asset('icon.png')); ?>">
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/components/favicon.blade.php ENDPATH**/ ?>