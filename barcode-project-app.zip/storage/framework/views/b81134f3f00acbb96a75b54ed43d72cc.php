<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-egg-900 leading-tight">
            <?php echo e(__('Buat Barcode Barang')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm border border-egg-200 sm:rounded-lg">
                <form action="<?php echo e(route('item-barcodes.store')); ?>" method="POST" class="p-6 space-y-6">
                    <?php echo csrf_field(); ?>

                    <div class="border-b pb-4">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">2A: Info Label Barang</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Perusahaan</label>
                                <select name="company_id" required class="mt-1 block w-full rounded-md border-egg-300">
                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>" <?php echo e(old('company_id') == $c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Code (Kode Unik) *</label>
                                <input type="text" name="code" value="<?php echo e(old('code')); ?>" required class="mt-1 block w-full rounded-md border-egg-300">
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Customer</label>
                                <input type="text" name="customer" value="<?php echo e(old('customer')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Part Name</label>
                                <input type="text" name="part_name" value="<?php echo e(old('part_name')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Part Number</label>
                                <input type="text" name="part_number" value="<?php echo e(old('part_number')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Model</label>
                                <input type="text" name="model" value="<?php echo e(old('model')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Berat</label>
                                <input type="number" step="0.01" name="berat" value="<?php echo e(old('berat')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Qty *</label>
                                <input type="number" name="qty" value="<?php echo e(old('qty', 0)); ?>" required class="mt-1 block w-full rounded-md border-egg-300">
                                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Inspector Name</label>
                                <input type="text" name="inspector_name" value="<?php echo e(old('inspector_name')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Tgl Produksi</label>
                                <input type="date" name="tgl_produksi" value="<?php echo e(old('tgl_produksi')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Tgl Expired</label>
                                <input type="date" name="tgl_expired" value="<?php echo e(old('tgl_expired')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Posisi Rak</label>
                                <input type="text" name="posisi_rak" value="<?php echo e(old('posisi_rak')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Tingkat</label>
                                <input type="text" name="tingkat" value="<?php echo e(old('tingkat')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                        </div>

                        <h4 class="text-md font-medium text-gray-700 mt-4 mb-2">Material</h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Ukuran Material</label>
                                <input type="text" name="ukuran_material" value="<?php echo e(old('ukuran_material')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Jenis Bahan</label>
                                <select name="jenis_bahan" class="mt-1 block w-full rounded-md border-egg-300">
                                    <option value="">-- Pilih --</option>
                                    <option value="SPCC" <?php echo e(old('jenis_bahan') == 'SPCC' ? 'selected' : ''); ?>>SPCC</option>
                                    <option value="SESE" <?php echo e(old('jenis_bahan') == 'SESE' ? 'selected' : ''); ?>>SESE</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Quantity Material</label>
                                <input type="number" name="quantity_material" value="<?php echo e(old('quantity_material')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">No Surat Jalan Material</label>
                                <input type="text" name="no_surat_jalan_material" value="<?php echo e(old('no_surat_jalan_material')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Tanggal Terima Material</label>
                                <input type="date" name="tanggal_terima_material" value="<?php echo e(old('tanggal_terima_material')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                        </div>
                    </div>

                    <div class="border-b pb-4">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">2B: Barang Masuk (Checker/Finishing)</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Nomor Transfer Slip</label>
                                <input type="text" name="transfer_slip_no" value="<?php echo e(old('transfer_slip_no')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Tanggal Terima FG ke Gudang</label>
                                <input type="date" name="tanggal_terima_fg" value="<?php echo e(old('tanggal_terima_fg')); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Jumlah Box</label>
                                <input type="number" name="jumlah_box" value="<?php echo e(old('jumlah_box', 0)); ?>" class="mt-1 block w-full rounded-md border-egg-300">
                            </div>
                        </div>
                    </div>

                    <div class="flex flex-wrap gap-4">
                        <button type="submit" class="btn-egg-primary">Generate Barcode</button>
                        <a href="<?php echo e(route('item-barcodes.index')); ?>" class="btn-egg-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/item-barcodes/create.blade.php ENDPATH**/ ?>