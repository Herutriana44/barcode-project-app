<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-wrap justify-between items-center gap-3">
            <h2 class="font-semibold text-xl text-egg-900 leading-tight">
                <?php echo e(__('Barcode Barang')); ?>

            </h2>
            <a href="<?php echo e(route('item-barcodes.create')); ?>" class="btn-egg-primary">
                Buat Baru
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm border border-egg-200 sm:rounded-lg">
                <div class="p-6">
                    <table class="min-w-full divide-y divide-egg-200">
                        <thead>
                            <tr>
                                <th class="px-4 py-2 text-left text-xs font-medium text-egg-700 uppercase">Barcode ID</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-egg-700 uppercase">Part Name</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-egg-700 uppercase">Code</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-egg-700 uppercase">Perusahaan</th>
                                <th class="px-4 py-2 text-left text-xs font-medium text-egg-700 uppercase">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-egg-200">
                            <?php $__empty_1 = true; $__currentLoopData = $itemBarcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-4 py-2"><?php echo e($ib->barcode_id); ?></td>
                                    <td class="px-4 py-2"><?php echo e($ib->item->part_name ?? '-'); ?></td>
                                    <td class="px-4 py-2"><?php echo e($ib->item->code ?? '-'); ?></td>
                                    <td class="px-4 py-2"><?php echo e($ib->item->company->name ?? '-'); ?></td>
                                    <td class="px-4 py-2">
                                        <a href="<?php echo e(route('item-barcodes.show', $ib)); ?>" class="link-egg">Lihat</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="px-4 py-8 text-center text-egg-700">Belum ada barcode barang. <a href="<?php echo e(route('item-barcodes.create')); ?>" class="link-egg">Buat baru</a></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <?php echo e($itemBarcodes->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/item-barcodes/index.blade.php ENDPATH**/ ?>