<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150 lg:px-8 lg:py-3.5 lg:text-sm lg:min-h-[3rem]'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/components/danger-button.blade.php ENDPATH**/ ?>