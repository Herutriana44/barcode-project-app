<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-wrap justify-between items-center gap-3">
            <h2 class="font-semibold text-xl text-egg-900 leading-tight">
                <?php echo e(__('Detail Barcode Barang')); ?>

            </h2>
            <div class="flex flex-wrap gap-2 justify-end">
                <button type="button" onclick="window.print()" class="btn-egg-primary">Print</button>
                <a href="<?php echo e(route('item-barcodes.create')); ?>" class="btn-egg-primary">Buat Baru</a>
                <a href="<?php echo e(route('item-barcodes.index')); ?>" class="btn-egg-secondary">Kembali</a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-2xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 print:shadow-none">
                <div class="border-2 border-egg-200 p-6 rounded-lg">
                    <div class="flex flex-col sm:flex-row flex-wrap items-start justify-center gap-10 mb-6 print:flex-row print:gap-8">
                        <div class="flex flex-col items-center w-full sm:w-auto">
                            <span class="text-xs font-medium text-egg-700 mb-2 uppercase tracking-wide">Barcode (Code 128)</span>
                            <div class="barcode-container overflow-x-auto max-w-full">
                                <?php echo $barcodeSvg; ?>

                            </div>
                        </div>
                        <div class="flex flex-col items-center w-full sm:w-auto">
                            <span class="text-xs font-medium text-egg-700 mb-2 uppercase tracking-wide">Kode QR</span>
                            <div class="qr-container w-[180px] max-w-full flex justify-center [&_svg]:max-w-full [&_svg]:h-auto">
                                <?php echo $qrCodeSvg; ?>

                            </div>
                        </div>
                    </div>
                    <p class="text-center text-base font-mono mb-6 font-medium text-egg-900"><?php echo e($itemBarcode->barcode_id); ?></p>

                    <div class="grid grid-cols-2 gap-4 text-sm">
                        <div><span class="font-medium">Customer:</span> <?php echo e($itemBarcode->item->customer ?? '-'); ?></div>
                        <div><span class="font-medium">Part Name:</span> <?php echo e($itemBarcode->item->part_name ?? '-'); ?></div>
                        <div><span class="font-medium">Part Number:</span> <?php echo e($itemBarcode->item->part_number ?? '-'); ?></div>
                        <div><span class="font-medium">Model:</span> <?php echo e($itemBarcode->item->model ?? '-'); ?></div>
                        <div><span class="font-medium">Berat:</span> <?php echo e($itemBarcode->item->berat ?? '-'); ?></div>
                        <div><span class="font-medium">Qty:</span> <?php echo e($itemBarcode->item->qty ?? '-'); ?></div>
                        <div><span class="font-medium">Inspector:</span> <?php echo e($itemBarcode->item->inspector_name ?? '-'); ?></div>
                        <div><span class="font-medium">Tgl Produksi:</span> <?php echo e($itemBarcode->item->tgl_produksi?->format('d/m/Y') ?? '-'); ?></div>
                        <div><span class="font-medium">Tgl Expired:</span> <?php echo e($itemBarcode->item->tgl_expired?->format('d/m/Y') ?? '-'); ?></div>
                        <div><span class="font-medium">Code:</span> <?php echo e($itemBarcode->item->code ?? '-'); ?></div>
                        <div><span class="font-medium">Posisi Rak:</span> <?php echo e($itemBarcode->item->posisi_rak ?? '-'); ?></div>
                        <div><span class="font-medium">Tingkat:</span> <?php echo e($itemBarcode->item->tingkat ?? '-'); ?></div>
                        <div class="col-span-2 border-t pt-2 mt-2"><span class="font-medium">Transfer Slip:</span> <?php echo e($itemBarcode->itemReceiving->transfer_slip_no ?? '-'); ?></div>
                        <div><span class="font-medium">Tgl Terima FG:</span> <?php echo e($itemBarcode->itemReceiving->tanggal_terima_fg?->format('d/m/Y') ?? '-'); ?></div>
                        <div><span class="font-medium">Jumlah Box:</span> <?php echo e($itemBarcode->itemReceiving->jumlah_box ?? '-'); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/item-barcodes/show.blade.php ENDPATH**/ ?>