<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-egg-900 leading-tight">
            <?php echo e(__('Scan Barcode')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            <?php if(session('error')): ?>
                <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm border border-egg-200 sm:rounded-lg p-6">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Camera Scan -->
                    <div>
                        <h3 class="text-lg font-medium text-egg-900 mb-4">Scan dengan Kamera</h3>
                        <div id="reader" class="w-full border-2 border-egg-200 rounded-lg overflow-hidden" style="min-height: 300px;"></div>
                        <p class="text-sm text-egg-700 mt-2">Arahkan kamera ke barcode garis (Code 128) atau ke kode QR pada label.</p>
                    </div>

                    <!-- Manual Input -->
                    <div>
                        <h3 class="text-lg font-medium text-egg-900 mb-4">Input Manual</h3>
                        <form id="manualScanForm">
                            <div class="flex flex-col sm:flex-row gap-2 sm:items-stretch">
                                <input type="text" id="barcode_input" placeholder="ID barcode / QR (IB-… atau CB-…)" class="flex-1 rounded-md border-egg-300 shadow-sm focus:border-egg-500 focus:ring-egg-500 min-h-[2.5rem]">
                                <button type="submit" class="btn-egg-primary shrink-0">Cari</button>
                            </div>
                        </form>
                        <p class="text-sm text-egg-700 mt-2">Ketik ID yang sama dengan pada label (barcode atau QR) lalu klik Cari.</p>
                    </div>
                </div>

                <!-- Result -->
                <div id="scan-result" class="mt-6 hidden">
                    <h3 class="text-lg font-medium text-egg-900 mb-4">Hasil Scan</h3>
                    <div id="result-content" class="p-4 bg-egg-50 border border-egg-200 rounded-lg"></div>
                </div>
            </div>
        </div>
    </div>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/scan.js']); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/herutriana44/Documents/barcode-project-app/resources/views/scan/index.blade.php ENDPATH**/ ?>